(async function () {
  let html = await fetch(chrome.runtime.getURL("inject.html")).then((r) => r.text());
  let div = document.createElement("div");
  div.innerHTML = html; 
  document.body.appendChild(div);
  let container = div.querySelector("ex-body");
  chrome.runtime.onMessage.addListener(function (m, s, sr) {
    if (m.ref === "toggle_body") {
      if (container.classList.contains("ds-none")) {
        container.classList.remove("ds-none");
      } else {
        container.classList.add("ds-none");
      }
    }
    return true;
  });
  // Create a hiddenInput element off-screen
  var hiddenInput = document.getElementById("hidden");
  function copyToClipboard(text) {
    hiddenInput.value = text;
    hiddenInput.select();
    document.execCommand("copy");
  }
  async function getClipboardText() {
    hiddenInput.focus();
    if (document.hasFocus()) {
      return await navigator.clipboard.readText();
    } else {
      document.execCommand("paste");
      return hiddenInput.value;
    }
  }

  let title = document.getElementById("markdown-title");
  let desc = document.getElementById("markdown-desc");
  let btns = document.querySelectorAll("button[copy]");
  let originalClipboardText = await getClipboardText();
  let url = "-";
  chrome.runtime.sendMessage({ref: "getCurrentTabTitle"}, async function (e) {
    title.value = e.title;
    url = e.url;
    desc.value = originalClipboardText;
    btns.forEach((btn) => {
      btn.addEventListener("click", function () {
        let t_value = title.value;
        let desc_value = desc.value;
        let command = this.getAttribute("btn");
        let parsed = "NOT DETECTED";
        if (command == "1") {
          parsed = `-**[${t_value}](${url})** *${desc_value}*\n`;
        } else if (command == "2") {
          parsed = `##[${t_value}](${url})\n *${desc_value}*\n`;
        } else if (command == "3") {
          parsed = `###[${t_value}](${url})\n *${desc_value}*\n`;
        }
        copyToClipboard(parsed);
      });
    });
  });
  console.log("...Markdown Running...");
})();
